"""SSIM-based structural comparison of two signature images.

SSIM (Structural Similarity Index Measure) compares local luminance, contrast
and structure of two images.  The score here describes how alike the two
*preprocessed images* are.  It is NOT a probability that the same person
signed, and it must not be used on its own to authenticate signatures.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
from skimage.metrics import structural_similarity

try:
    from .config import DEFAULT_CONFIG, SignatureConfig
    from .preprocessing import (
        ImageSource,
        SignatureError,
        preprocess_signature,
        validate_for_ssim,
    )
except ImportError:  # pragma: no cover
    from config import DEFAULT_CONFIG, SignatureConfig
    from preprocessing import (
        ImageSource,
        SignatureError,
        preprocess_signature,
        validate_for_ssim,
    )

#: Pixel range of the uint8 images handed to SSIM (255 - 0).
SSIM_DATA_RANGE = 255


def _error_result(error_type: str, message: str, image: Optional[str] = None) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "ssim_score": None,
        "similarity_percentage": None,
        "status": "error",
        "error_type": error_type,
        "message": message,
    }
    if image is not None:
        result["image"] = image
    return result


def compute_ssim(
    img1: np.ndarray, img2: np.ndarray, config: SignatureConfig = DEFAULT_CONFIG
) -> float:
    """SSIM between two already-preprocessed, equally sized uint8 images."""
    validate_for_ssim(img1, img2, config)
    return float(
        structural_similarity(
            img1,
            img2,
            data_range=SSIM_DATA_RANGE,
            win_size=config.ssim_win_size,
        )
    )


def compare_signatures(
    image1: ImageSource,
    image2: ImageSource,
    config: Optional[SignatureConfig] = None,
    include_preprocessed: bool = False,
) -> Dict[str, Any]:
    """Compare two signature images with SSIM.

    Args:
        image1, image2: image paths (PNG/JPG/JPEG/BMP) or image arrays.
        config: optional :class:`SignatureConfig` (canvas size etc.).
        include_preprocessed: also return the two preprocessed arrays under
            ``"preprocessed_images"`` (for visual inspection).

    Returns:
        On success::

            {"ssim_score": float, "similarity_percentage": float,
             "status": "success"}

        ``ssim_score`` is the raw SSIM in [-1, 1]. ``similarity_percentage``
        is ``ssim_score * 100`` clamped to [0, 100]; it is a rescaled image
        similarity, not a probability of identity.

        On failure (never raises for bad inputs)::

            {"ssim_score": None, "similarity_percentage": None,
             "status": "error", "error_type": str, "message": str,
             "image": "image1" | "image2"   # when one input is at fault
            }
    """
    cfg = config or DEFAULT_CONFIG

    processed = []
    for label, source in (("image1", image1), ("image2", image2)):
        try:
            processed.append(preprocess_signature(source, cfg))
        except SignatureError as exc:
            return _error_result(type(exc).__name__, f"{label}: {exc}", image=label)
        except Exception as exc:  # defensive: never leak unexpected crashes
            return _error_result(
                "UnexpectedError", f"{label}: {type(exc).__name__}: {exc}", image=label
            )

    try:
        score = compute_ssim(processed[0], processed[1], cfg)
    except SignatureError as exc:
        return _error_result(type(exc).__name__, str(exc))
    except Exception as exc:
        return _error_result("UnexpectedError", f"{type(exc).__name__}: {exc}")

    result: Dict[str, Any] = {
        "ssim_score": score,
        "similarity_percentage": float(min(max(score, 0.0), 1.0) * 100.0),
        "status": "success",
    }
    if include_preprocessed:
        result["preprocessed_images"] = (processed[0], processed[1])
    return result
