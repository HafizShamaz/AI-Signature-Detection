"""Configuration for signature similarity (Task 4).

All tunable values live in :class:`SignatureConfig` so that preprocessing and
similarity code contain no magic numbers.  Nothing in here is an
authentication threshold: SSIM is a structural image metric, not a decision
rule for genuine vs. forged signatures.
"""

from dataclasses import dataclass

#: Image file extensions accepted when a file path is given.
SUPPORTED_EXTENSIONS = (".png", ".jpg", ".jpeg", ".bmp")


@dataclass(frozen=True)
class SignatureConfig:
    """Tunable parameters for preprocessing and SSIM.

    Attributes:
        target_width / target_height: Size (pixels) of the canvas both
            signatures are fitted onto before SSIM is computed.
        canvas_padding: White border (pixels) kept free around the signature
            on the canvas.
        crop_margin: White margin (pixels) kept when cropping to the ink
            bounding box.
        ssim_win_size: Odd window size used by scikit-image's SSIM.
        min_contrast: Minimum difference between the darkest and lightest
            pixel (0-255) for an image to be considered as containing ink.
        min_ink_pixels: Minimum number of ink pixels (after speckle removal)
            required; fewer means the image is treated as blank.
        speckle_min_area: Connected ink components smaller than this many
            pixels are treated as noise and ignored.
        min_input_size: Smallest accepted image side in pixels.
        align_by_centroid: Place the signature so its ink centre of mass is
            near the canvas centre (clamped to stay inside the canvas).
            If False the bounding box is centred instead.
    """

    target_width: int = 400
    target_height: int = 200
    canvas_padding: int = 10
    crop_margin: int = 2
    ssim_win_size: int = 7
    min_contrast: int = 30
    min_ink_pixels: int = 20
    speckle_min_area: int = 3
    min_input_size: int = 8
    align_by_centroid: bool = True

    def __post_init__(self) -> None:
        if self.ssim_win_size < 3 or self.ssim_win_size % 2 == 0:
            raise ValueError("ssim_win_size must be an odd integer >= 3")
        if self.canvas_padding < 0 or self.crop_margin < 0:
            raise ValueError("canvas_padding and crop_margin must be >= 0")
        inner_w = self.target_width - 2 * self.canvas_padding
        inner_h = self.target_height - 2 * self.canvas_padding
        if inner_w < self.ssim_win_size or inner_h < self.ssim_win_size:
            raise ValueError(
                "target size minus padding must be at least ssim_win_size "
                "in both dimensions"
            )
        if self.target_width < self.ssim_win_size or self.target_height < self.ssim_win_size:
            raise ValueError("target size must be at least ssim_win_size")
        if not (0 <= self.min_contrast <= 255):
            raise ValueError("min_contrast must be in [0, 255]")
        if self.min_ink_pixels < 1 or self.speckle_min_area < 1 or self.min_input_size < 1:
            raise ValueError("min_ink_pixels, speckle_min_area, min_input_size must be >= 1")


DEFAULT_CONFIG = SignatureConfig()
