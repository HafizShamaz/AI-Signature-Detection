#!/usr/bin/env python3
"""Write a few SYNTHETIC signature-like PNGs for trying compare_example.py.

These are drawn with OpenCV (Hershey text + flourish line), not real signatures.

Usage: python examples/generate_sample_signatures.py [output_dir]
"""

import sys
from pathlib import Path

import cv2
import numpy as np


def draw(text, seed, thickness=2, offset=(0, 0), size=(500, 220)):
    w, h = size
    img = np.full((h, w, 3), 255, np.uint8)
    font = cv2.FONT_HERSHEY_SCRIPT_COMPLEX
    (tw, th), _ = cv2.getTextSize(text, font, 2.0, thickness)
    x, y = (w - tw) // 2 + offset[0], (h + th) // 2 - 15 + offset[1]
    cv2.putText(img, text, (x, y), font, 2.0, (20, 20, 20), thickness, cv2.LINE_AA)
    rng = np.random.default_rng(seed)
    pts = np.stack([np.linspace(x, x + tw, 8),
                    y + 20 + rng.uniform(-8, 18, 8) + offset[1]], 1).astype(np.int32)
    cv2.polylines(img, [pts.reshape(-1, 1, 2)], False, (20, 20, 20), thickness, cv2.LINE_AA)
    return img


def main():
    out = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).parent / "sample_signatures")
    out.mkdir(parents=True, exist_ok=True)
    samples = {
        "john_smith_1.png": draw("John Smith", 1),
        "john_smith_2.png": draw("John Smith", 1, thickness=3, offset=(6, -4)),
        "maria_lopez.png": draw("Maria Lopez", 7),
    }
    for name, img in samples.items():
        cv2.imwrite(str(out / name), img)
        print("wrote", out / name)


if __name__ == "__main__":
    main()
