#!/usr/bin/env python3
"""Compare two local signature images using SSIM.

Usage:
    python examples/compare_example.py --image1 a.png --image2 b.png
    python examples/compare_example.py --image1 a.png --image2 b.png \
        --save-preprocessed out_dir

Exit code: 0 on success, 1 if the comparison failed (see printed message).
"""

import argparse
import sys
from pathlib import Path

import cv2

# Allow running from anywhere without installing the package.
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from signature_similarity import SignatureConfig, compare_signatures  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare two signature images with SSIM.")
    parser.add_argument("--image1", required=True, help="path to first signature image")
    parser.add_argument("--image2", required=True, help="path to second signature image")
    parser.add_argument("--width", type=int, default=SignatureConfig.target_width,
                        help="canvas width used for comparison (default: %(default)s)")
    parser.add_argument("--height", type=int, default=SignatureConfig.target_height,
                        help="canvas height used for comparison (default: %(default)s)")
    parser.add_argument("--save-preprocessed", metavar="DIR",
                        help="optional directory to save the preprocessed images")
    args = parser.parse_args()

    try:
        config = SignatureConfig(target_width=args.width, target_height=args.height)
    except ValueError as exc:
        print(f"Invalid configuration: {exc}")
        return 1

    result = compare_signatures(
        args.image1, args.image2, config=config,
        include_preprocessed=bool(args.save_preprocessed),
    )

    print(f"Image 1 : {args.image1}")
    print(f"Image 2 : {args.image2}")
    if result["status"] == "success":
        print(f"SSIM score            : {result['ssim_score']:.4f}")
        print(f"Similarity percentage : {result['similarity_percentage']:.2f}%")
        print(f"Status                : {result['status']}")
        print("Note: SSIM measures image structure similarity only; it is not a "
              "probability of identity or a genuine/forged verdict.")
        if args.save_preprocessed:
            out_dir = Path(args.save_preprocessed)
            out_dir.mkdir(parents=True, exist_ok=True)
            for name, img in zip(("image1", "image2"), result["preprocessed_images"]):
                cv2.imwrite(str(out_dir / f"{name}_preprocessed.png"), img)
            print(f"Preprocessed images saved to: {out_dir}")
        return 0

    print("SSIM score            : n/a")
    print("Similarity percentage : n/a")
    print(f"Status                : {result['status']} ({result['error_type']})")
    print(f"Message               : {result['message']}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
