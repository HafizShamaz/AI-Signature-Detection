"""Signature similarity using SSIM (standalone, Task 4)."""

from .config import DEFAULT_CONFIG, SUPPORTED_EXTENSIONS, SignatureConfig
from .preprocessing import (
    BlankImageError,
    ImageNotFoundError,
    InvalidImageError,
    SignatureError,
    UnsupportedFormatError,
    preprocess_signature,
)
from .similarity import compare_signatures, compute_ssim

__all__ = [
    "BlankImageError",
    "DEFAULT_CONFIG",
    "ImageNotFoundError",
    "InvalidImageError",
    "SUPPORTED_EXTENSIONS",
    "SignatureConfig",
    "SignatureError",
    "UnsupportedFormatError",
    "compare_signatures",
    "compute_ssim",
    "preprocess_signature",
]
