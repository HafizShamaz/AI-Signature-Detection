"""Image loading, validation and preprocessing for signature comparison.

Pipeline (see :func:`preprocess_signature`):

1. load / validate input (path or array)
2. convert to grayscale (transparent PNGs are composited onto white)
3. normalise polarity (light-on-dark becomes dark-on-light) and background
4. detect ink (Otsu threshold + speckle removal); reject blank images
5. crop white margins to the ink bounding box
6. stretch contrast so the darkest ink is 0 and the background is 255
7. resize preserving aspect ratio (never stretch)
8. paste onto a white canvas of fixed size, aligned by ink centroid
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Union

import cv2
import numpy as np

try:  # package import
    from .config import DEFAULT_CONFIG, SUPPORTED_EXTENSIONS, SignatureConfig
except ImportError:  # pragma: no cover - allows running modules directly
    from config import DEFAULT_CONFIG, SUPPORTED_EXTENSIONS, SignatureConfig

ImageSource = Union[str, "os.PathLike[str]", np.ndarray]


# --------------------------------------------------------------------------
# Exceptions
# --------------------------------------------------------------------------
class SignatureError(Exception):
    """Base class for all signature-similarity errors."""


class ImageNotFoundError(SignatureError):
    """The image path does not exist or is not a file."""


class UnsupportedFormatError(SignatureError):
    """The file extension is not one of the supported formats."""


class InvalidImageError(SignatureError):
    """The input is corrupted, empty, or otherwise not a usable image."""


class BlankImageError(SignatureError):
    """The image contains no detectable signature ink."""


# --------------------------------------------------------------------------
# Loading
# --------------------------------------------------------------------------
def load_image(source: ImageSource, config: SignatureConfig = DEFAULT_CONFIG) -> np.ndarray:
    """Load an image from a path or validate an array.

    Returns the decoded image unchanged in channel layout (2-D gray, or 3/4
    channel BGR/BGRA) so transparency can be handled in :func:`to_grayscale`.

    Raises:
        ImageNotFoundError, UnsupportedFormatError, InvalidImageError.
    """
    if isinstance(source, np.ndarray):
        return _validate_array(source, config)

    if isinstance(source, (str, os.PathLike)):
        path = Path(source)
        if not path.exists():
            raise ImageNotFoundError(f"File not found: {path}")
        if not path.is_file():
            raise ImageNotFoundError(f"Path is not a file: {path}")
        ext = path.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise UnsupportedFormatError(
                f"Unsupported image format '{ext or '(none)'}'. "
                f"Supported: {', '.join(SUPPORTED_EXTENSIONS)}"
            )
        try:
            data = np.fromfile(str(path), dtype=np.uint8)  # works with unicode paths
        except OSError as exc:
            raise InvalidImageError(f"Could not read file {path}: {exc}") from exc
        if data.size == 0:
            raise InvalidImageError(f"File is empty: {path}")
        try:
            image = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
        except cv2.error as exc:
            raise InvalidImageError(f"Corrupted or unreadable image {path}: {exc}") from exc
        if image is None:
            raise InvalidImageError(f"Corrupted or unreadable image: {path}")
        return _validate_array(image, config)

    raise InvalidImageError(
        f"Image must be a file path or numpy array, got {type(source).__name__}"
    )


def _validate_array(image: np.ndarray, config: SignatureConfig) -> np.ndarray:
    if image.ndim not in (2, 3):
        raise InvalidImageError(f"Image must be 2-D or 3-D, got {image.ndim}-D array")
    if image.ndim == 3 and image.shape[2] not in (1, 3, 4):
        raise InvalidImageError(f"Unsupported channel count: {image.shape[2]}")
    h, w = image.shape[:2]
    if h < config.min_input_size or w < config.min_input_size:
        raise InvalidImageError(
            f"Image too small ({w}x{h}); minimum side is {config.min_input_size}px"
        )
    if image.dtype == np.uint8:
        return image
    if image.dtype == np.uint16:
        return (image / 257.0).round().astype(np.uint8)
    if np.issubdtype(image.dtype, np.floating):
        if not np.all(np.isfinite(image)):
            raise InvalidImageError("Float image contains NaN or infinite values")
        if image.min() < 0.0 or image.max() > 1.0:
            raise InvalidImageError("Float images must have values in [0, 1]")
        return (image * 255.0).round().astype(np.uint8)
    raise InvalidImageError(f"Unsupported array dtype: {image.dtype}")


# --------------------------------------------------------------------------
# Individual preprocessing steps
# --------------------------------------------------------------------------
def to_grayscale(image: np.ndarray) -> np.ndarray:
    """Convert a loaded image to single-channel uint8 grayscale.

    BGRA images are alpha-composited onto a white background so that
    transparent PNG signatures do not turn into black rectangles.
    """
    if image.ndim == 2:
        return image.copy()
    channels = image.shape[2]
    if channels == 1:
        return image[:, :, 0].copy()
    if channels == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if channels == 4:
        alpha = image[:, :, 3:4].astype(np.float32) / 255.0
        bgr = image[:, :, :3].astype(np.float32)
        composited = bgr * alpha + 255.0 * (1.0 - alpha)
        return cv2.cvtColor(composited.round().astype(np.uint8), cv2.COLOR_BGR2GRAY)
    raise InvalidImageError(f"Unsupported channel count: {channels}")


def normalize_polarity(gray: np.ndarray) -> np.ndarray:
    """Ensure dark signature on light background (invert if background is dark)."""
    if float(np.median(gray)) < 127.0:
        return 255 - gray
    return gray


def normalize_background(gray: np.ndarray) -> np.ndarray:
    """Scale intensities so the typical background (median) becomes white."""
    bg = float(np.median(gray))
    if bg < 1.0:
        raise BlankImageError("Image has no usable background level (all black)")
    scaled = gray.astype(np.float32) * (255.0 / bg)
    return np.clip(scaled, 0, 255).round().astype(np.uint8)


def detect_ink_mask(gray: np.ndarray, config: SignatureConfig = DEFAULT_CONFIG) -> np.ndarray:
    """Return a boolean mask of signature ink pixels.

    Raises:
        BlankImageError: if the image has too little contrast or ink.
    """
    if int(gray.max()) - int(gray.min()) < config.min_contrast:
        raise BlankImageError("Image is blank (no contrast between ink and background)")

    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Drop tiny speckles (scanner/JPEG noise) so they do not enlarge the crop.
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    keep = np.zeros(n, dtype=bool)
    keep[1:] = stats[1:, cv2.CC_STAT_AREA] >= config.speckle_min_area
    mask = keep[labels]

    if int(mask.sum()) < config.min_ink_pixels:
        raise BlankImageError("Image is blank (no signature ink detected)")
    return mask


def crop_to_ink(
    gray: np.ndarray, mask: np.ndarray, margin: int
) -> tuple[np.ndarray, np.ndarray]:
    """Crop gray image and mask to the ink bounding box (plus ``margin`` px)."""
    ys, xs = np.nonzero(mask)
    y0 = max(int(ys.min()) - margin, 0)
    y1 = min(int(ys.max()) + 1 + margin, gray.shape[0])
    x0 = max(int(xs.min()) - margin, 0)
    x1 = min(int(xs.max()) + 1 + margin, gray.shape[1])
    return gray[y0:y1, x0:x1], mask[y0:y1, x0:x1]


def stretch_contrast(gray: np.ndarray) -> np.ndarray:
    """Map the darkest pixel to 0 and keep the white background at 255."""
    lo = int(gray.min())
    if 255 - lo < 1:
        raise BlankImageError("Image has no contrast after cropping")
    stretched = (gray.astype(np.float32) - lo) * (255.0 / (255 - lo))
    return np.clip(stretched, 0, 255).round().astype(np.uint8)


def fit_to_canvas(gray: np.ndarray, config: SignatureConfig = DEFAULT_CONFIG) -> np.ndarray:
    """Resize preserving aspect ratio and paste onto a white fixed-size canvas."""
    width, height = config.target_width, config.target_height
    pad = config.canvas_padding
    inner_w, inner_h = width - 2 * pad, height - 2 * pad

    h, w = gray.shape
    scale = min(inner_w / w, inner_h / h)
    new_w = max(1, min(inner_w, int(round(w * scale))))
    new_h = max(1, min(inner_h, int(round(h * scale))))
    interp = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_CUBIC
    resized = cv2.resize(gray, (new_w, new_h), interpolation=interp)

    x0 = (width - new_w) // 2
    y0 = (height - new_h) // 2

    if config.align_by_centroid:
        weights = 255.0 - resized.astype(np.float64)
        total = weights.sum()
        if total > 0:
            cx = float((weights.sum(axis=0) * np.arange(new_w)).sum() / total)
            cy = float((weights.sum(axis=1) * np.arange(new_h)).sum() / total)
            x0 = int(round(width / 2.0 - cx))
            y0 = int(round(height / 2.0 - cy))
            x0 = min(max(x0, 0), width - new_w)  # keep signature inside canvas
            y0 = min(max(y0, 0), height - new_h)

    canvas = np.full((height, width), 255, dtype=np.uint8)
    canvas[y0 : y0 + new_h, x0 : x0 + new_w] = resized
    return canvas


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------
def preprocess_signature(
    source: ImageSource, config: SignatureConfig = DEFAULT_CONFIG
) -> np.ndarray:
    """Run the full preprocessing pipeline.

    Args:
        source: image path (PNG/JPG/JPEG/BMP) or an image array.
        config: preprocessing parameters.

    Returns:
        uint8 grayscale array of shape ``(target_height, target_width)`` with
        a dark signature on a white background.

    Raises:
        SignatureError subclasses for missing, unsupported, corrupted or
        blank inputs.
    """
    loaded = load_image(source, config)
    gray = to_grayscale(loaded)
    gray = normalize_polarity(gray)
    gray = normalize_background(gray)
    mask = detect_ink_mask(gray, config)
    cropped, _ = crop_to_ink(gray, mask, config.crop_margin)
    cropped = stretch_contrast(cropped)
    return fit_to_canvas(cropped, config)


def validate_for_ssim(
    img1: np.ndarray, img2: np.ndarray, config: SignatureConfig = DEFAULT_CONFIG
) -> None:
    """Check two preprocessed images are suitable for an SSIM comparison.

    Raises:
        InvalidImageError: wrong type/dtype/dimensionality, mismatched shapes,
            too small for the SSIM window, or constant (blank) content.
    """
    for name, img in (("image1", img1), ("image2", img2)):
        if not isinstance(img, np.ndarray) or img.ndim != 2 or img.dtype != np.uint8:
            raise InvalidImageError(f"{name} must be a 2-D uint8 array for SSIM")
        if min(img.shape) < config.ssim_win_size:
            raise InvalidImageError(
                f"{name} is smaller than the SSIM window ({config.ssim_win_size}px)"
            )
        if int(img.max()) == int(img.min()):
            raise BlankImageError(f"{name} is constant; SSIM is not meaningful")
    if img1.shape != img2.shape:
        raise InvalidImageError(
            f"Image shapes differ after preprocessing: {img1.shape} vs {img2.shape}"
        )
