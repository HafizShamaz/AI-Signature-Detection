"""Tests for signature_similarity.preprocessing (standalone, no backend)."""

import cv2
import numpy as np
import pytest

import signature_similarity.tests.helpers as helpers
from signature_similarity import (
    BlankImageError,
    ImageNotFoundError,
    InvalidImageError,
    SignatureConfig,
    UnsupportedFormatError,
    preprocess_signature,
)
from signature_similarity.preprocessing import (
    crop_to_ink,
    detect_ink_mask,
    to_grayscale,
    validate_for_ssim,
)

CFG = SignatureConfig()


def test_output_shape_dtype_and_white_background():
    out = preprocess_signature(helpers.draw_signature())
    assert out.shape == (CFG.target_height, CFG.target_width)
    assert out.dtype == np.uint8
    assert out[0, 0] == 255 and out[-1, -1] == 255  # white padding
    assert out.min() < 50  # dark ink present


def test_custom_dimensions_are_respected():
    cfg = SignatureConfig(target_width=300, target_height=120)
    out = preprocess_signature(helpers.draw_signature(), cfg)
    assert out.shape == (120, 300)


def test_invalid_config_rejected():
    with pytest.raises(ValueError):
        SignatureConfig(ssim_win_size=4)
    with pytest.raises(ValueError):
        SignatureConfig(target_width=20, target_height=20, canvas_padding=10)


def test_margins_do_not_change_result():
    base = helpers.draw_signature()
    padded = helpers.add_margins(base, top=90, bottom=30, left=150, right=10)
    assert np.array_equal(preprocess_signature(base), preprocess_signature(padded))


def _ink_ratio(gray_img, thresh):
    ys, xs = np.nonzero(gray_img < thresh)
    return (xs.max() - xs.min() + 1) / (ys.max() - ys.min() + 1)


def test_aspect_ratio_is_preserved_not_stretched():
    # Wide signature (limited by canvas width) and tall one (limited by
    # canvas height): the ink bounding-box ratio must survive resizing.
    wide = helpers.draw_signature()
    tall = cv2.rotate(wide, cv2.ROTATE_90_CLOCKWISE)
    for img in (wide, tall):
        gray = to_grayscale(img)
        cropped, _ = crop_to_ink(gray, detect_ink_mask(gray, CFG), 0)
        in_ratio = cropped.shape[1] / cropped.shape[0]
        out_ratio = _ink_ratio(preprocess_signature(img), 200)
        assert abs(out_ratio - in_ratio) / in_ratio < 0.05, (in_ratio, out_ratio)


def test_thin_line_is_not_stretched_vertically():
    # Extreme aspect ratio: result must stay a thin, wide line (a few px
    # tall), not be inflated to fill the canvas height.
    img = np.full((300, 600, 3), 255, np.uint8)
    cv2.line(img, (50, 150), (550, 150), (0, 0, 0), 4)
    out = preprocess_signature(img)
    rows = np.nonzero((out < 255).any(axis=1))[0]
    assert len(rows) <= 8
    assert out.shape == (CFG.target_height, CFG.target_width)


def test_light_on_dark_is_inverted_to_dark_on_light():
    base = helpers.draw_signature()
    assert np.array_equal(preprocess_signature(base), preprocess_signature(255 - base))


def test_grayscale_and_color_inputs_equivalent():
    base = helpers.draw_signature()
    gray = cv2.cvtColor(base, cv2.COLOR_BGR2GRAY)
    assert np.array_equal(preprocess_signature(base), preprocess_signature(gray))


def test_transparent_png_is_composited_on_white():
    base = helpers.draw_signature()
    alpha = (255 - cv2.cvtColor(base, cv2.COLOR_BGR2GRAY)).astype(np.uint8)
    bgra = np.dstack([np.zeros_like(base), alpha])  # black ink, alpha = stroke
    out = preprocess_signature(bgra)
    ref = preprocess_signature(base)
    assert out[0, 0] == 255
    assert np.mean(np.abs(out.astype(int) - ref.astype(int))) < 10


def test_speckle_noise_does_not_enlarge_crop():
    base = helpers.draw_signature()
    noisy = base.copy()
    noisy[2, 2] = 0  # single stray dark pixel in a far corner
    noisy[-3, -3] = 0
    assert np.array_equal(preprocess_signature(base), preprocess_signature(noisy))


def test_supported_formats_load(tmp_path):
    base = helpers.draw_signature()
    for ext in (".png", ".jpg", ".jpeg", ".bmp", ".PNG"):
        path = helpers.save(base, tmp_path / f"sig{ext}")
        out = preprocess_signature(path)
        assert out.shape == (CFG.target_height, CFG.target_width), ext


def test_blank_white_image_rejected():
    with pytest.raises(BlankImageError):
        preprocess_signature(np.full((200, 300, 3), 255, np.uint8))


def test_blank_black_image_rejected():
    with pytest.raises(BlankImageError):
        preprocess_signature(np.zeros((200, 300, 3), np.uint8))


def test_nearly_uniform_noise_is_blank():
    rng = np.random.default_rng(0)
    noise = (250 + rng.integers(-2, 3, size=(200, 300))).astype(np.uint8)
    with pytest.raises(BlankImageError):
        preprocess_signature(noise)


def test_missing_file_rejected(tmp_path):
    with pytest.raises(ImageNotFoundError):
        preprocess_signature(tmp_path / "nope.png")


def test_directory_path_rejected(tmp_path):
    with pytest.raises(ImageNotFoundError):
        preprocess_signature(tmp_path)


def test_unsupported_formats_rejected(tmp_path):
    for name in ("sig.gif", "sig.txt", "sig.tiff", "sig"):
        p = tmp_path / name
        p.write_bytes(b"whatever")
        with pytest.raises(UnsupportedFormatError):
            preprocess_signature(p)


def test_corrupted_files_rejected(tmp_path):
    garbage = tmp_path / "garbage.png"
    garbage.write_bytes(np.random.default_rng(1).bytes(2048))
    with pytest.raises(InvalidImageError):
        preprocess_signature(garbage)

    empty = tmp_path / "empty.jpg"
    empty.write_bytes(b"")
    with pytest.raises(InvalidImageError):
        preprocess_signature(empty)

    good = helpers.save(helpers.draw_signature(), tmp_path / "good.png")
    truncated = tmp_path / "truncated.png"
    truncated.write_bytes(good.read_bytes()[:40])
    with pytest.raises(InvalidImageError):
        preprocess_signature(truncated)


def test_bad_input_types_rejected():
    for bad in (None, 42, [1, 2, 3], np.zeros((0, 0), np.uint8), np.zeros((50,), np.uint8)):
        with pytest.raises(InvalidImageError):
            preprocess_signature(bad)


def test_tiny_image_rejected():
    with pytest.raises(InvalidImageError):
        preprocess_signature(np.zeros((3, 3), np.uint8))


def test_out_of_range_float_rejected():
    with pytest.raises(InvalidImageError):
        preprocess_signature(np.full((50, 50), 7.5, dtype=np.float32))


def test_validate_for_ssim_checks():
    ok = preprocess_signature(helpers.draw_signature())
    validate_for_ssim(ok, ok.copy())  # no error
    with pytest.raises(InvalidImageError):
        validate_for_ssim(ok, ok[:-1])  # shape mismatch
    with pytest.raises(InvalidImageError):
        validate_for_ssim(ok, ok.astype(np.float32))  # wrong dtype
    with pytest.raises(BlankImageError):
        validate_for_ssim(ok, np.full_like(ok, 255))  # constant image
