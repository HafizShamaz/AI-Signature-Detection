"""Tests for signature_similarity.similarity (standalone, no backend).

Scores for *different* signatures are never hard-coded; those tests only
assert relative ordering against the identical / same-signature cases.
"""

import cv2
import numpy as np

import signature_similarity.tests.helpers as helpers
from signature_similarity import SignatureConfig, compare_signatures

REFERENCE = helpers.draw_signature("John Smith", seed=1)


def _score(a, b, **kw):
    res = compare_signatures(a, b, **kw)
    assert res["status"] == "success", res
    return res["ssim_score"]


def test_result_structure_on_success():
    res = compare_signatures(REFERENCE, REFERENCE)
    assert set(res) == {"ssim_score", "similarity_percentage", "status"}
    assert res["status"] == "success"
    assert isinstance(res["ssim_score"], float)
    assert 0.0 <= res["similarity_percentage"] <= 100.0


def test_image_with_itself_is_close_to_one():
    res = compare_signatures(REFERENCE, REFERENCE)
    assert res["ssim_score"] > 0.999
    assert res["similarity_percentage"] > 99.9


def test_image_file_with_itself(tmp_path):
    p = helpers.save(REFERENCE, tmp_path / "a.png")
    assert _score(p, str(p)) > 0.999  # Path and str both accepted


def test_symmetry():
    other = helpers.draw_signature("Maria Lopez", seed=7)
    assert abs(_score(REFERENCE, other) - _score(other, REFERENCE)) < 1e-9


def test_similar_signatures_score_above_different_ones():
    similar = [
        helpers.draw_signature("John Smith", seed=1, thickness=3, offset=(6, -4)),
        helpers.draw_signature("John Smith", seed=1, angle=2),
        helpers.draw_signature("John Smith", seed=2),
    ]
    different = [
        helpers.draw_signature("Maria Lopez", seed=7),
        helpers.draw_signature("Xu Qiang", seed=9),
    ]
    worst_similar = min(_score(REFERENCE, s) for s in similar)
    best_different = max(_score(REFERENCE, d) for d in different)
    assert worst_similar > best_different


def test_different_signatures_score_below_identical():
    other = helpers.draw_signature("Maria Lopez", seed=7)
    assert _score(REFERENCE, other) < _score(REFERENCE, REFERENCE) - 0.05


def test_different_dimensions_are_handled():
    big = cv2.resize(REFERENCE, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    small = cv2.resize(REFERENCE, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    different = helpers.draw_signature("Maria Lopez", seed=7)
    assert big.shape != REFERENCE.shape
    s_big = _score(REFERENCE, big)
    s_small = _score(REFERENCE, small)
    s_diff = _score(REFERENCE, different)
    assert s_big > s_diff and s_small > s_diff


def test_different_white_margins_do_not_matter():
    padded = helpers.add_margins(REFERENCE, top=120, bottom=10, left=40, right=200)
    assert _score(REFERENCE, padded) > 0.999


def test_polarity_does_not_matter():
    assert _score(REFERENCE, 255 - REFERENCE) > 0.999


def test_custom_dimensions():
    cfg = SignatureConfig(target_width=240, target_height=100)
    res = compare_signatures(REFERENCE, REFERENCE, config=cfg, include_preprocessed=True)
    assert res["status"] == "success"
    a, b = res["preprocessed_images"]
    assert a.shape == b.shape == (100, 240)


def test_array_inputs_accepted():
    gray = cv2.cvtColor(REFERENCE, cv2.COLOR_BGR2GRAY)
    assert _score(REFERENCE, gray) > 0.999


def _assert_error(res, error_type, image=None):
    assert res["status"] == "error"
    assert res["ssim_score"] is None and res["similarity_percentage"] is None
    assert res["error_type"] == error_type
    assert isinstance(res["message"], str) and res["message"]
    if image:
        assert res["image"] == image and res["message"].startswith(image)


def test_blank_image_returns_error():
    blank = np.full((200, 300, 3), 255, np.uint8)
    _assert_error(compare_signatures(REFERENCE, blank), "BlankImageError", "image2")
    _assert_error(compare_signatures(blank, REFERENCE), "BlankImageError", "image1")


def test_corrupted_file_returns_error(tmp_path):
    bad = tmp_path / "bad.png"
    bad.write_bytes(b"\x89PNG\r\n\x1a\nthis is not really a png")
    _assert_error(compare_signatures(REFERENCE, bad), "InvalidImageError", "image2")


def test_unsupported_format_returns_error(tmp_path):
    p = tmp_path / "sig.gif"
    p.write_bytes(b"GIF89a")
    _assert_error(compare_signatures(p, REFERENCE), "UnsupportedFormatError", "image1")


def test_missing_path_returns_error(tmp_path):
    res = compare_signatures(REFERENCE, tmp_path / "missing.png")
    _assert_error(res, "ImageNotFoundError", "image2")
    assert "missing.png" in res["message"]


def test_none_input_returns_error():
    _assert_error(compare_signatures(None, REFERENCE), "InvalidImageError", "image1")


def test_error_results_never_raise_for_bad_inputs(tmp_path):
    for bad in (None, 5, "", tmp_path, tmp_path / "x.png", np.zeros((2, 2), np.uint8)):
        res = compare_signatures(bad, bad)
        assert res["status"] == "error"
