"""Shared helpers for building deterministic synthetic 'signatures' in tests.

Real signatures are not bundled, so signature-like strokes are drawn with
OpenCV (Hershey-font text plus a hand-drawn-looking flourish).  Everything is
seeded, so tests are deterministic.
"""

import sys
from pathlib import Path

import cv2
import numpy as np

# Make `import signature_similarity` work wherever pytest is launched from.
_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


def draw_signature(
    text="John Smith",
    seed=1,
    size=(500, 220),
    thickness=2,
    font_scale=2.0,
    offset=(0, 0),
    angle=0.0,
):
    """Return a BGR uint8 image with a dark 'signature' on white."""
    w, h = size
    img = np.full((h, w, 3), 255, dtype=np.uint8)
    font = cv2.FONT_HERSHEY_SCRIPT_COMPLEX
    (tw, th), _ = cv2.getTextSize(text, font, font_scale, thickness)
    x = (w - tw) // 2 + offset[0]
    y = (h + th) // 2 - 15 + offset[1]
    cv2.putText(img, text, (x, y), font, font_scale, (20, 20, 20), thickness, cv2.LINE_AA)

    # Seeded flourish underline: different seeds give different shapes.
    rng = np.random.default_rng(seed)
    xs = np.linspace(x, x + tw, 8)
    ys = y + 20 + rng.uniform(-8, 18, size=8) + offset[1]
    pts = np.stack([xs, ys], axis=1).astype(np.int32).reshape(-1, 1, 2)
    cv2.polylines(img, [pts], False, (20, 20, 20), thickness, cv2.LINE_AA)

    if angle:
        m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
        img = cv2.warpAffine(img, m, (w, h), borderValue=(255, 255, 255))
    return img


def add_margins(img, top=0, bottom=0, left=0, right=0, value=255):
    return cv2.copyMakeBorder(
        img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(value,) * 3
    )


def save(img, path):
    ok = cv2.imwrite(str(path), img)
    assert ok, f"could not write {path}"
    return path
