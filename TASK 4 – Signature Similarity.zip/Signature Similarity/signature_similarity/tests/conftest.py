"""pytest bootstrap: make `helpers` and `signature_similarity` importable
regardless of pytest's import mode or the directory it is launched from."""

import sys
from pathlib import Path

_TESTS_DIR = Path(__file__).resolve().parent          # .../signature_similarity/tests
_PACKAGE_PARENT = _TESTS_DIR.parents[1]               # folder containing signature_similarity/

for _p in (_TESTS_DIR, _PACKAGE_PARENT):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
