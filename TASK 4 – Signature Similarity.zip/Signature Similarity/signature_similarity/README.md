# Signature Similarity (SSIM) — Task 4

A standalone Python module that compares two handwritten-signature images
using the **Structural Similarity Index Measure (SSIM)**. It has no
dependency on FastAPI, Redis, Celery, PostgreSQL, YOLO or MLOps code.

## What is SSIM?

SSIM compares two images through local windows, combining three things:
luminance (brightness), contrast, and structure (pixel patterns). The score
is in `[-1, 1]`; `1.0` means the two images are identical. Here it is
computed with `skimage.metrics.structural_similarity` on 8-bit grayscale
images with `data_range=255`.

## How signature similarity works here

1. Both inputs are **preprocessed** into the same normalized form
   (dark signature, white background, same canvas size).
2. SSIM is computed between the two preprocessed images.
3. The result is returned as a dict:

```python
{"ssim_score": 0.7659, "similarity_percentage": 76.59, "status": "success"}
```

`similarity_percentage` is simply `ssim_score × 100` clamped to `[0, 100]`.
**It is not a probability that the same person signed**, and this module
applies no genuine/forged threshold.

On failure nothing is raised for bad input; you get:

```python
{"ssim_score": None, "similarity_percentage": None, "status": "error",
 "error_type": "BlankImageError", "message": "image2: Image is blank ...",
 "image": "image2"}
```

## Project structure

```
signature_similarity/
├── __init__.py                 public API
├── config.py                   SignatureConfig (canvas size, thresholds, ...)
├── preprocessing.py            loading, validation, cleanup, resize, padding
├── similarity.py               compare_signatures(), compute_ssim()
├── requirements.txt
├── tests/
│   ├── helpers.py              synthetic signature generator for tests
│   ├── test_preprocessing.py
│   └── test_similarity.py
├── examples/
│   ├── compare_example.py      CLI: compare two images
│   └── generate_sample_signatures.py   makes synthetic sample PNGs
└── README.md
```

## Dependencies and installation

Python 3.9+ with `numpy`, `opencv-python`, `scikit-image`, and `pytest`
(for tests). Install only what is missing:

```bash
pip install -r signature_similarity/requirements.txt
```

Tip: avoid having several OpenCV wheels (`opencv-python`,
`opencv-python-headless`, `opencv-contrib-python`) installed together;
they overwrite each other's `cv2` files.

## How preprocessing works

| Step | What happens |
|------|--------------|
| Load | Path (`.png .jpg .jpeg .bmp`, case-insensitive) or array. Decoded with OpenCV from raw bytes, so unicode paths work. |
| Grayscale | BGR → gray. Transparent PNGs are composited onto white. |
| Polarity | If the median pixel is dark (light-on-dark image), the image is inverted. |
| Background | Intensities are scaled so the background becomes white. |
| Ink detection | Otsu threshold; connected components smaller than `speckle_min_area` are dropped as noise. Too little contrast or ink → `BlankImageError`. |
| Crop | White margins removed using the ink bounding box (+ `crop_margin`). |
| Contrast | Darkest ink mapped to 0, background kept at 255. |
| Resize | Scaled to fit inside the canvas **keeping aspect ratio** (never stretched). |
| Canvas | Pasted on a white `target_width × target_height` canvas (default 400×200, `canvas_padding` 10) and aligned by ink centroid (or bbox centre if `align_by_centroid=False`). |

Everything is configurable via `SignatureConfig`, e.g.
`SignatureConfig(target_width=600, target_height=300)`.

Error types (all subclass `SignatureError`): `ImageNotFoundError`,
`UnsupportedFormatError`, `InvalidImageError`, `BlankImageError`.

## Running a standalone comparison

From the directory that contains `signature_similarity/`:

```bash
python signature_similarity/examples/compare_example.py \
    --image1 path/to/signature1.png --image2 path/to/signature2.png

# optional: save preprocessed images for visual inspection
python signature_similarity/examples/compare_example.py \
    --image1 a.png --image2 b.png --save-preprocessed out_dir
```

No real signatures handy? Generate synthetic samples:

```bash
python signature_similarity/examples/generate_sample_signatures.py sample_signatures
```

From Python:

```python
from signature_similarity import compare_signatures
print(compare_signatures("a.png", "b.png"))
```

## Running the automated tests

```bash
cd <directory containing signature_similarity/>
python -m pytest signature_similarity/tests -v
```

Tests cover: identical images, similar vs. different signatures (relative
comparison only, no hard-coded scores for different signatures), different
dimensions, different margins, polarity, blank images, corrupted files,
unsupported formats and missing paths. Test signatures are synthetic and
deterministic.

## Limitations of SSIM for signature verification

- **It is not an authentication method.** SSIM measures pixel-level
  structural similarity, not whether the same person wrote both signatures.
- **Genuine signatures vary.** The same person's signatures differ in size,
  slant, speed and pen pressure; small shifts, rotation or stroke-thickness
  changes can lower SSIM a lot.
- **Skilled forgeries can score high**, and genuine signatures can score low.
- **Scores for unrelated signatures are not near 0.** Large shared white
  background regions score as similar, so different signatures commonly land
  well above zero (about 0.6–0.7 on the synthetic examples). Compare scores
  relatively; do not read them as absolute percentages.
- **Resampling effects:** the same signature at different resolutions
  does not score exactly 1.0 after resizing.
- **Preprocessing assumptions:** a roughly uniform background, one signature
  per image, ink darker than paper. Shadows, ruled lines, stamps or
  multiple signatures in one image are not handled.
- **No alignment beyond centroid/crop:** no rotation or slant correction.

Any decision logic (thresholds, genuine/forged classification) would need a
properly evaluated approach with real labeled data and is out of scope.
